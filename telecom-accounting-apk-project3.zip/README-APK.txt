بناء تطبيق أندرويد (APK) — الطريقة الأسهل: GitHub Actions (بدون تثبيت أي برامج)

1) أنشئ حساباً مجانياً على github.com ثم مستودعاً جديداً (New repository) واجعله Private.
2) اضغط Add file ثم Upload files، واسحب إليه كل محتويات هذا المجلد (www و assets و .github و package.json وغيرها)، ثم Commit.
   - إذا لم يُرفع مجلد .github (لأنه مخفي): اضغط Add file > Create new file، واكتب الاسم  .github/workflows/build-apk.yml  والصق فيه محتوى الملف build-apk.yml.txt.
3) افتح تبويب Actions، اختر Build APK، ثم Run workflow. انتظر 5 إلى 10 دقائق.
4) عند النجاح افتح التشغيل وحمّل الملف telecom-accounting-apk من قسم Artifacts، فك ضغطه لتحصل على app-debug.apk.
5) انقله إلى الهاتف وافتحه، وفعّل «التثبيت من مصادر غير معروفة» إن طلب الهاتف.

التحديثات: عدّل ملف www/index.html في المستودع وشغّل Build APK مرة أخرى، ثم ثبّت الملف الجديد فوق القديم (التوقيع ثابت فلا تُفقد بياناتك).

الحفظ التلقائي: بعد كل تعديل يُحفظ ملف النسخة في Documents/TelecomBackup على الهاتف، مع ملف لكل يوم (آخر 14 يوماً).

البناء على حاسوبك بدلاً من ذلك: ثبّت Node 20 و JDK 17 و Android Studio ثم نفّذ:
  npm install
  npx cap add android
  npx cap sync android
  cd android && ./gradlew assembleDebug
الملف الناتج: android/app/build/outputs/apk/debug/app-debug.apk

هذا الملف debug للاستخدام الشخصي. للنشر على Google Play تحتاج نسخة release موقّعة بمفتاحك الخاص.
